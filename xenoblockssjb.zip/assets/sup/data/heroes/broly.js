function init(hero) {
    hero.setName("Broly");
    hero.setTier(9);
    
    hero.setChestplate("SSJL");
    
    hero.addPowers("sup:brolysaiyan_physiology", "sup:brolyssjl");
    hero.addAttribute("PUNCH_DAMAGE", 13.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 3, 0);
    hero.addAttribute("KNOCKBACK", 4.0, 0);
    hero.addAttribute("BASE_SPEED", -0.1, 1);
    hero.addAttribute("FALL_RESISTANCE", 100.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);
    
    hero.addKeyBind("AIM", "Grab/Ki Blast", 2);
    hero.addKeyBind("CHARGED_BEAM", "Saiyan Blaster", 1);
    hero.addKeyBind("TELEKINESIS", "Grab/Ki Blast", 2);
    hero.addKeyBind("NANITE_TRANSFORM", "(Legend) Super-Saiyan", 5);
    
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.supplyFunction("canAim", canAim);
    
    hero.addAttributeProfile("SUPER", superProfile);
    hero.addAttributeProfile("SUITUP", suitupProfile);
    hero.setAttributeProfile(getProfile);
    hero.setDefaultScale(defaultScale);
    hero.setDamageProfile(getProfile);
    hero.addDamageProfile("BLADE", {
        "types": {
            "SHARP": 1.0,
            "ENERGY": 0.7
        }
    });
    
    hero.addSoundEvent("MASK_OPEN", "fiskheroes:mk50_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:mk50_mask_close");
    hero.addSoundEvent("STEP", "sup:walk");
    hero.addSoundEvent("PUNCH", "sup:punch");
    hero.addSoundEvent("AIM_START", "sup:han");
    hero.addSoundEvent("AIM_STOP", "sup:han");
}

function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/nanites") ? 8 : 0;
}

function suitupProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", -10, 0);
    profile.addAttribute("STEP_HEIGHT", -10, 0);
    profile.addAttribute("JUMP_HEIGHT", -10, 0);
}

function defaultScale(entity) {
    if (entity.getData('fiskheroes:dyn/nanites')) {
        return 1.4;
    }
    return 1.0;
}

function isKeyBindEnabled(entity, keyBind) {
    return keyBind != "CHARGED_BEAM" || entity.getData("fiskheroes:beam_charge") == 0 && entity.getData("fiskheroes:aimed_timer") == 1;
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:beam_charge") == 0 && entity.getData('fiskheroes:time_since_damaged') > 10;
}

function superProfile(profile) {
    profile.addAttribute("PUNCH_DAMAGE", 7, 0);
    profile.addAttribute("FALL_RESISTANCE", 50.0, 0);
    profile.addAttribute("SPRINT_SPEED", 0, 0);
}

function getProfile(entity) {
    if (entity.getData('fiskheroes:dyn/nanite_timer') > 0 && entity.getData('fiskheroes:dyn/nanite_timer') < 1) {
        return "SUITUP"
    } else if (!entity.getData("fiskheroes:dyn/nanites")) {
        return "SUPER";
    }
    
    return entity.getData("fiskheroes:blade") ? "BLADE" : null;
}

function isModifierEnabled(entity, modifier) {
    if (modifier.name() != "fiskheroes:transformation" && modifier.name() != "fiskheroes:cooldown" && (!entity.getData("fiskheroes:dyn/nanites") || modifier.name() == "fiskheroes:propelled_flight" && entity.getData("fiskheroes:dyn/nanite_timer") < 1)) {
        return true;
    }
  
    switch (modifier.name()) {
    case "fiskheroes:energy_blast":
        return entity.getData("fiskheroes:aimed_timer") >= 1;
    case "fiskheroes:blade":
        return !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:shield");
    case "fiskheroes:regeneration":
        return !entity.getData("fiskheroes:blade");
    case "fiskheroes:flight":
        return entity.getData("fiskheroes:dyn/nanites") && !entity.isSprinting() && !entity.getData("fiskheroes:gliding");
    case "fiskheroes:hover":
            return  !entity.getData("fiskheroes:gliding");
    case "fiskheroes:water_breathing":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    if (keyBind == "NANITE_TRANSFORM") {
        return entity.getData("fiskheroes:mask_open_timer") == 0;
    }
    else if (!entity.getData("fiskheroes:dyn/nanites")) {
        return false;
    }
    
    switch (keyBind) {
    case "SHIELD":
        return entity.isSneaking() || entity.isBookPlayer();
    case "BLADE":
        return !entity.isSneaking() && !entity.getData("fiskheroes:shield");
    default:
        return true;
    }
}

function hasProperty(entity, property) {
    switch (property) {
    case "BREATHE_SPACE":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    default:
        return false;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:dyn/nanites") && !entity.getData("fiskheroes:jetpacking") && !entity.getData("fiskheroes:shield");
}