function init(hero) {
    hero.setName("Vegeta");
    hero.setTier(8);
    
    hero.setChestplate("SSJ2/SSJB");
    
    hero.addPowers("sup:saiyan_physiology", "sup:ssj");
    hero.addAttribute("PUNCH_DAMAGE", 9.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 2, 0);
    hero.addAttribute("KNOCKBACK", 3.0, 0);
    hero.addAttribute("BASE_SPEED", 0.1, 1);
    hero.addAttribute("FALL_RESISTANCE", 100.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);
    
    hero.addKeyBind("AIM", "Ki Blast", 2);
    hero.addKeyBind("CHARGED_BEAM", "Galick Gun", 1);
    hero.addKeyBindFunc("func_GIANT_MODE", giantModeKey, "Super-Saiyan Blue", 2);
    hero.addKeyBind("NANITE_TRANSFORM", "Super-Vegeta", 5);
    
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.supplyFunction("canAim", canAim);
    
    hero.addAttributeProfile("SUPER", superProfile);
    hero.addAttributeProfile("GIANT_MODE", giantProfile);
    hero.addAttributeProfile("SUITUP", suitupProfile);
    hero.setAttributeProfile(getProfile);
    hero.setDefaultScale(defaultScale);
    hero.setDamageProfile(getProfile);
    hero.addDamageProfile("BLADE", {
        "types": {
            "SHARP": 1.0,
            "ENERGY": 0.7
        }
    });
    
    hero.addSoundEvent("MASK_OPEN", "fiskheroes:mk50_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:mk50_mask_close");
    hero.addSoundEvent("PUNCH", "sup:punch");
    hero.addSoundEvent("AIM_START", "sup:han");
    hero.addSoundEvent("AIM_STOP", "sup:han");
}

function giantModeKey(player, manager) {
    var flag = player.getData("fiskheroes:dyn/giant_mode");
    manager.setData(player, "fiskheroes:dyn/giant_mode", !flag);
    manager.setData(player, "fiskheroes:size_state", flag ? -1 : 1);
    return true;
}

function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/giant_mode") ? 6 : 4;
}


function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/nanites") ? 8 : 0;
}

function giantProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 14.0, 0);
    profile.addAttribute("JUMP_HEIGHT", 3, 0);
    profile.addAttribute("KNOCKBACK", 4.0, 0);
    profile.addAttribute("BASE_SPEED", 0.5, 1);
    profile.addAttribute("FALL_RESISTANCE", 100.0, 0);
    profile.addAttribute("SPRINT_SPEED", 0.5, 1);
}

function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/nanites") ? 8 : 0;
}

function suitupProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", -10, 0);
    profile.addAttribute("STEP_HEIGHT", -10, 0);
    profile.addAttribute("JUMP_HEIGHT", -10, 0);
}


function getAttributeProfile(entity) {
    return entity.getData("fiskheroes:dyn/giant_mode_timer") > 0 ? "GIANT_MODE" : null;
}

function defaultScale(entity) {
    if (entity.getData('fiskheroes:dyn/nanites')) {
        return 1.0;
    }
    return 1.0;
}

function isKeyBindEnabled(entity, keyBind) {
    return keyBind != "CHARGED_BEAM" || entity.getData("fiskheroes:beam_charge") == 0 && entity.getData("fiskheroes:aimed_timer") == 1;
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:beam_charge") == 0 && entity.getData('fiskheroes:time_since_damaged') > 10;
}

function superProfile(profile) {
    profile.addAttribute("PUNCH_DAMAGE", 3, 0);
    profile.addAttribute("FALL_RESISTANCE", 50.0, 0);
    profile.addAttribute("SPRINT_SPEED", 0, 0);
}

function getProfile(entity) {
    if (entity.getData("fiskheroes:dyn/giant_mode") ) {
        return "GIANT_MODE";
    } else if (!entity.getData("fiskheroes:dyn/nanites")) {
        return "SUPER";
    }
    
    return entity.getData("fiskheroes:blade") ? "BLADE" : null;
}

function isModifierEnabled(entity, modifier) {
    if (modifier.name() != "fiskheroes:transformation" && modifier.name() != "fiskheroes:cooldown" && (!entity.getData("fiskheroes:dyn/nanites") || modifier.name() == "fiskheroes:propelled_flight" && entity.getData("fiskheroes:dyn/nanite_timer") < 1)) {
        return true;
    }
  
    switch (modifier.name()) {
    case "fiskheroes:energy_blast":
        return entity.getData("fiskheroes:aimed_timer") >= 1;
    case "fiskheroes:blade":
        return !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:shield");
    case "fiskheroes:regeneration":
        return !entity.getData("fiskheroes:blade");
    case "fiskheroes:flight":
        return entity.getData("fiskheroes:dyn/nanites") && !entity.isSprinting() && !entity.getData("fiskheroes:gliding");
    case "fiskheroes:hover":
            return  !entity.getData("fiskheroes:gliding");
    case "fiskheroes:transformation|2":
            return  !entity.getData("fiskheroes:dyn/giant_mode");
    case "fiskheroes:transformation":
            return  !entity.getData("fiskheroes:dyn/giant_mode");
    case "fiskheroes:water_breathing":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    default:
        return true;
    }
}

function isModifierEnabled(entity, modifier) {
    if (modifier.name() != "fiskheroes:transformation|2" && modifier.name() != "fiskheroes:cooldown" && (!entity.getData("fiskheroes:dyn/nanites") || modifier.name() == "fiskheroes:propelled_flight" && entity.getData("fiskheroes:dyn/nanite_timer") < 1)) {
        return true;
    }
  
    switch (modifier.name()) {
    case "fiskheroes:energy_blast":
        return entity.getData("fiskheroes:aimed_timer") >= 1;
    case "fiskheroes:blade":
        return !entity.getData("fiskheroes:aiming") && !entity.getData("fiskheroes:shield");
    case "fiskheroes:regeneration":
        return !entity.getData("fiskheroes:blade");
    case "fiskheroes:flight":
        return entity.getData("fiskheroes:dyn/nanites") && !entity.isSprinting() && !entity.getData("fiskheroes:gliding");
    case "fiskheroes:hover":
            return  !entity.getData("fiskheroes:gliding");
    case "fiskheroes:transformation":
            return  !entity.getData("fiskheroes:dyn/giant_mode");
    case "fiskheroes:transformation|2":
            return  !entity.getData("fiskheroes:dyn/giant_mode");
    case "fiskheroes:water_breathing":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    if (keyBind == "NANITE_TRANSFORM") {
        return entity.getData("fiskheroes:dyn/giant_mode") == 0;
    }
    if (keyBind == "func_GIANT_MODE") {
        return entity.getData("fiskheroes:dyn/nanites") == 0;
    }
    if (keyBind == "AIM") {
        return !entity.getData("fiskheroes:dyn/nanites") == 0;
    }
    if (keyBind == "ENERGY_PROJECTION") {
        return !entity.getData("fiskheroes:dyn/giant_mode") == 0;
    }
	if (keyBind == "func_GIANT_MODE") {
        return true;
    }
    else if (!entity.getData("fiskheroes:dyn/giant_mode") && !entity.getData("fiskheroes:dyn/nanites")) {
        return false;
    }
    
    switch (keyBind) {
    case "SHIELD":
        return entity.isSneaking() || entity.isBookPlayer();
    case "BLADE":
        return !entity.isSneaking() && !entity.getData("fiskheroes:shield");
    default:
        return true;
    }
}

function hasProperty(entity, property) {
    switch (property) {
    case "BREATHE_SPACE":
        return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
    default:
        return false;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:dyn/nanites") && !entity.getData("fiskheroes:jetpacking") && !entity.getData("fiskheroes:shield");
}